#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main(int argc, char const *argv[])
{
    printf("before exec\n");
    execl("/bin/ls","/bin/ls",NULL);
    printf("after exec\n");
    return 0;

}