#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
   
   //./projbin source.txt dest.txt
  int main(int argc,char const *argv[])
  {
      int fdr,fdw;
      char buffer[50];
      fdr=open(argv[1],O_RDONLY);
      fdw=open(argv[2],O_WRONLY|O_CREAT,S_IRUSR|S_IWUSR);

      if(fdr==-1|fdw==-1)
      {
          perror("error:\n");
          exit(EXIT_FAILURE);
      }
     // printf("File descriptor for src.txt:%d\n", fdr);
     // printf("File descriptor for desd.txt:%d\n", fdw);
      
      read(fdr,buffer,50);
      write(fdw,buffer,strlen(buffer));
      close(fdr);
      close(fdw);
      return 0;
  }
