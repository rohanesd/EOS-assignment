#include<stdio.h>

#include "arith.h"

  int main(int argc, char const *argv[])
  {
       printf("add:%d\n",add(10,90,30));
       return 0;
    
  }